import pyimgur

CLIENT_ID = "f0e83904a2dee5a"



im = pyimgur.Imgur(CLIENT_ID)
uploaded_image = im.upload_image("utkarsh-aki.jpg", title="Uploaded with PyImgur")
print(uploaded_image.title)
print(uploaded_image.link)
print(uploaded_image.size)
print(uploaded_image.type)