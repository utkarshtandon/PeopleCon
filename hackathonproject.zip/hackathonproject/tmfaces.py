import base64
import json
import requests

from base64 import b64encode

client_id = 'f0e83904a2dee5a'

headers = {"Authorization": "Client-ID f0e83904a2dee5a"}

api_key = 'nagas'

url = "https://api.imgur.com/3/image"

j1 = requests.post(
    url, 
    headers = headers,
    data = {
        'key': api_key, 
        'image': b64encode(open('utkarsh-aki.jpg', 'rb').read()),
        'type': 'base64',
        'name': '1.jpg',
        'title': 'Picture no. 1'
    }
)

print j1